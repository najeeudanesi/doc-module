import React from "react";

function Medication() {
  return (
    <div>
      {" "}
      <div className="m-t-40">Medication</div>
    </div>
  );
}

export default Medication;
