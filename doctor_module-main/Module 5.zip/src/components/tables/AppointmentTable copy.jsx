import { Clock10Icon } from "lucide-react";
import React, { useEffect, useState } from "react";
import { get } from "../../utility/fetch";
import { formatDate } from "../../utility/general";
import NurseNotes from "../modals/NurseNotes";
import ViewVisit from "../modals/ViewVisit";

function AppointmentTable({ patientId, next }) {
    const [modalData, setModalData] = useState(null); // State to store the data for the modal
    const [noteModalData, setNoteModalData] = useState(null); // State to store the data for the note modal
    const [data, setData] = useState([]);
    const [isloading, setIsLoading] = useState(false)
    const [totalPages, setTotalPages] = useState(0);
    const [currentPage, setCurrentPage] = useState(1)

    const handlePageChange = (newPage) => {
        if (newPage > 0 && newPage <= totalPages) {
            setCurrentPage(newPage);
        }
    };
    const generatePageNumbers = () => {
        let pages = [];
        if (totalPages <= 5) {
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i);
            }
        } else {
            if (currentPage <= 3) {
                pages = [1, 2, 3, 4, totalPages];
            } else if (currentPage >= totalPages - 2) {
                pages = [1, totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
            } else {
                pages = [1, currentPage - 1, currentPage, currentPage + 1, totalPages];
            }
        }
        return pages;

    };

    const fetchData = async (currentPage) => {
        try {
            const response = await get(`/appointment/get-appointment-bypatientId/${patientId}?pageIndex=${currentPage}&pageSize=10`);
            setData(response?.data)
            console.log(response.data)
            setTotalPages(response?.pageCount);

        } catch (e) {
            console.log(e);
        }
    };

    useEffect(() => {
        fetchData(currentPage);
    }, [currentPage]);

    return (
        <div className="w-100">
            {!isloading ? (
                <div className="w-100 none-flex-item m-t-40">
                    <table className="bordered-table-2">
                        <thead className="border-top-none">
                            <tr className="border-top-none">

                                <th className="center-text">Date</th>
                                <th className="center-text">Time</th>
                                <th className="center-text">Description</th>
                                <th className="center-text">Patient Name</th>
                                <th className="center-text">Tracking</th>
                                <th className="center-text">Doctor</th>
                                <th className="center-text">Nurse</th>
                                <th className="center-text"> </th>



                            </tr>
                        </thead>

                        <tbody className="white-bg view-det-pane">
                            {data.map((row) => (
                                <tr key={row?.id}>
                                    <td>{formatDate(row?.appointDate)}</td>
                                    <td>{row?.appointTime}</td>
                                    <td>{row?.description}</td>
                                    <td>{row?.patientName}</td>
                                    <td>{row?.tracking}</td>
                                    <td>{row?.doctor}</td>
                                    <td>{row?.nurse}</td>
                                    <td ><div className="rounded-btn-yellow w-75 flex flex-v-center gap-2 flex-h-center" ><Clock10Icon /> </div></td>


                                </tr>
                            ))}
                        </tbody>
                    </table>

                    <div>
                        <div className="pagination flex space-between  col-4 m-t-20">
                            <div className="flex gap-8">
                                <div className="bold-text">Page</div> <div className=" m-r-20">{currentPage}/{totalPages}</div>
                            </div>
                            <div className="flex gap-8">
                                <button
                                    className={`pagination-btn ${currentPage === 1 ? 'disabled' : ''}`}
                                    onClick={() => handlePageChange(currentPage - 1)}
                                    disabled={currentPage === 1}
                                >
                                    {"Previous"}
                                </button>

                                {generatePageNumbers().map((page, index) => (
                                    <button
                                        key={`page-${index}`}
                                        className={`pagination-btn ${currentPage === page ? 'bg-green text-white' : ''}`}
                                        onClick={() => handlePageChange(page)}
                                    >
                                        {page}
                                    </button>
                                ))}

                                <button
                                    className={`pagination-btn ${currentPage === totalPages ? 'disabled' : ''}`}
                                    onClick={() => handlePageChange(currentPage + 1)}
                                    disabled={currentPage === totalPages}
                                >
                                    {"Next"}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>


            ) : (<div>Loading....</div>)}

            {modalData && <ViewVisit closeModal={() => setModalData(null)} visit={modalData} next={next} />}
            {noteModalData && <NurseNotes closeModal={() => setNoteModalData(null)} data={noteModalData} next={next} patientId={patientId} />}


        </div>
    );
}

export default AppointmentTable;
