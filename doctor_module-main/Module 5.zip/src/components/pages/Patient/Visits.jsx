import React from "react";

function Visits() {
  return <div>Visits</div>;
}

export default Visits;
