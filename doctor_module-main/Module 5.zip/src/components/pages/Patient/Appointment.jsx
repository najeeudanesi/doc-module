import React from "react";

function Appointment() {
  return (
    <div>
      {" "}
      <div className="m-t-40">Appointment</div>
    </div>
  );
}

export default Appointment;
